package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public abstract class ActivityAbstract extends AppCompatActivity {

static public int test1 = 0;
public int test2 = 0;

}
