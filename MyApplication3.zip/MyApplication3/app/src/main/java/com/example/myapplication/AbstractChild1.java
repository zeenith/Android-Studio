package com.example.myapplication;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class AbstractChild1 extends ActivityAbstract {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.child1);

        Button BoutonChanger = findViewById(R.id.buttonchild2);
        Button Boutonplus = findViewById(R.id.buttonplus);
        Button Boutonmoins = findViewById(R.id.buttonmoins);
        TextView chiffre = findViewById(R.id.monTexte);


        BoutonChanger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.e("DEVE0304", "Button clicked");
                Intent intent = new Intent(view.getContext(), AbstractChild2.class);
                view.getContext().startActivity(intent);

                setContentView(R.layout.child2);

            }
        });


        Boutonplus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.e("DEVE0304", "Button clicked");


                test1++;
                chiffre.setText(""+test1);

            }
        });

        Boutonmoins.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.e("DEVE0304", "Button clicked");


                test1--;
                chiffre.setText(""+test1);


            }
        });



    }


}
